import java.util.List;

public interface LiteraryWork {
    String getTitle();
    void setTitle(String title);

    int getServicePages();
    void setServicePages(int servicePages);

    List<Integer> getPageCounts();
    void setPageCounts(List<Integer> pageCounts);

    int getArrayElement(int index) throws IndexOutOfBoundsException;
    void setArrayElement(int index, int pages) throws IndexOutOfBoundsException;

    int calculateUsefulPages() throws InvalidBookDataException;
}